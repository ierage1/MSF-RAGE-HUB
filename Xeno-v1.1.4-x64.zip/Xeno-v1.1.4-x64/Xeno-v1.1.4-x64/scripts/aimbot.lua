﻿local library = loadstring(game:HttpGet("https://raw.githubusercontent.com/miroeramaa/TurtleLib/main/TurtleUiLib.lua"))()
loadstring(game:HttpGet("https://raw.githubusercontent.com/Exunys/Aimbot-V2/main/Resources/Scripts/Raw%20Main.lua"))()
getgenv().Aimbot.Settings.Enabled = false
getgenv().Aimbot.FOVSettings.Sides = 15
getgenv().Aimbot.FOVSettings.Visible = false
getgenv().Aimbot.FOVSettings.Thickness = 2

local combat = library:Window("Combat")

combat:Button("Silent Aim", function()
	local localPlayer = game:GetService("Players").LocalPlayer
	local currentCamera = game:GetService("Workspace").CurrentCamera
	local mouse = localPlayer:GetMouse()

	local function getClosestPlayerToCursor(x, y)
		local closestPlayer = nil
		local shortestDistance = math.huge

		for i, v in pairs(game:GetService("Players"):GetPlayers()) do
			if v ~= localPlayer and v.Character and v.Character:FindFirstChild("Humanoid") and v.Character.Humanoid.Health ~= 0 and v.Character:FindFirstChild("HumanoidRootPart") and v.Character:FindFirstChild("Head") then
				local pos = currentCamera:WorldToViewportPoint(v.Character.HumanoidRootPart.Position)
				local magnitude = (Vector2.new(pos.X, pos.Y) - Vector2.new(x, y)).magnitude

				if magnitude < shortestDistance then
					closestPlayer = v
					shortestDistance = magnitude
				end
			end
		end

		return closestPlayer
	end

	local mt = getrawmetatable(game)
	local oldIndex = mt.__index
	if setreadonly then setreadonly(mt, false) else make_writeable(mt, true) end
	local newClose = newcclosure or function(f) return f end

	mt.__index = newClose(function(t, k)
		if not checkcaller() and t == mouse and tostring(k) == "X" and string.find(getfenv(2).script.Name, "Client") and getClosestPlayerToCursor() then
			local closest = getClosestPlayerToCursor(oldIndex(t, k), oldIndex(t, "Y")).Character.Head
			local pos = currentCamera:WorldToScreenPoint(closest.Position)
			return pos.X
		end
		if not checkcaller() and t == mouse and tostring(k) == "Y" and string.find(getfenv(2).script.Name, "Client") and getClosestPlayerToCursor() then
			local closest = getClosestPlayerToCursor(oldIndex(t, "X"), oldIndex(t, k)).Character.Head
			local pos = currentCamera:WorldToScreenPoint(closest.Position)
			return pos.Y
		end
		if t == mouse and tostring(k) == "Hit" and string.find(getfenv(2).script.Name, "Client") and getClosestPlayerToCursor() then
			return getClosestPlayerToCursor(mouse.X, mouse.Y).Character.Head.CFrame
		end

		return oldIndex(t, k)
	end)

	if setreadonly then setreadonly(mt, true) else make_writeable(mt, false) end
end)

combat:Toggle("Aimbot", false, function(bool)
	getgenv().Aimbot.Settings.Enabled = bool
end)

combat:Toggle("FOV Circle", false, function(bool)
	getgenv().Aimbot.FOVSettings.Visible = bool
end)

combat:Slider("FOV", 50, 250, 190, function(value)
	print(value)
	getgenv().Aimbot.FOVSettings.Amount = value
end)

combat:ColorPicker("FOV Color", Color3.fromRGB(255, 255, 255), function(color)
	getgenv().Aimbot.FOVSettings.Color = color
end)